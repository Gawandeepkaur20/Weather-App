import 'package:flutter/material.dart';
import 'package:mausam/worker.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class Loading extends StatefulWidget {
  @override
  _LoadingState createState() => _LoadingState();
}

class _LoadingState extends State<Loading> {
  String city = "London"; // Default city
  String? temp;
  String? hum;
  String? airSpeed;
  String? description;
  String? mainWeather;
  String? icon;

  void startApp(String city) async {
    try {
      worker instance = worker(location: city);
      await instance.getData();

      if (mounted) {
        setState(() {
          temp = instance.temp;
          hum = instance.humidity;
          airSpeed = instance.air_speed;
          description = instance.description;
          mainWeather = instance.main;
          icon = instance.icon;
        });
      }

      Future.delayed(Duration(seconds: 2), () {
        Navigator.pushReplacementNamed(context, '/home', arguments: {
          "temp_value": temp,
          "hum_value": hum,
          "air_speed_value": airSpeed,
          "des_value": description,
          "main_value": mainWeather,
          "icon_value": icon,
          "city_value": city,
        });
      });
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch data: $e')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      startApp(city);
    });
  }

  @override
  Widget build(BuildContext context) {
    final search =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    city = search?['searchText'] ?? "London";

    return Scaffold(
        body: Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Colors.blue.shade800, Colors.blue.shade300],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: 200),
            Image.asset(
              "images/weather.png",
              cacheWidth: 250,
            ),
            Text("Mausam App",
                style: GoogleFonts.acme(
                    fontWeight: FontWeight.bold, fontSize: 30)),
            SizedBox(height: 10),
            Text("Made by Gawandeep",
                style: GoogleFonts.acme(
                    fontWeight: FontWeight.bold, fontSize: 25)),
            SizedBox(height: 30),
            SpinKitWave(color: Colors.white, size: 50.0),
          ],
        ),
      ),
    ));
  }
}
